//
//  ViewController2.swift
//  TheosCode
//
//  Created by Hussein Salah on 3/2/20.
//  Copyright © 2020 Riley Norris. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func messege(_ sender: Any)
    {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    @IBAction func PayPal(_ sender: Any)
    {
        UIApplication.shared.open(URL(string: "https://www.paypal.me/AhmedSalahStore")! as URL, options : [:],completionHandler: nil)
    }
    
    
    @IBAction func gitHub(_ sender: Any)
    {
        UIApplication.shared.open(URL(string: "https://www.paypal.me/AhmedSalahStore")! as URL, options : [:],completionHandler: nil)
    }
 
    
    
    
    
    
    
    
//
//    @IBAction func instagram(_ sender: Any)
//    {
//        UIApplication.shared.open(URL(string: "https://saveig.org/itsfioriii/")! as URL, options : [:],completionHandler: nil)
//    }
    
    
    
    
}

