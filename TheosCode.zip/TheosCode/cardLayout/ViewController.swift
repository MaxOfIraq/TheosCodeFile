//
//  ViewController.swift
//  TheosCode
//
//  Created by Ahmed Salah on 11/2/19.
//  Copyright © 2019 Ahmed Salah. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    override func viewDidLoad() {
    }
    
    
    
    let locationNames = ["Code Respring (Method)", "code open in Sfafari (Method)", "code Button (Plist)", "code switch (Plist)", "code lable (Plist)", "code messege (Method)", "code copyrights (Plist)", "code Library (Tweak.xm)", "code makefile (Plist)", "code Library (hedor)", "code makefile (TweakBundle)", "code Group (Tweak.xm)"]
    
   
    
    let locationDescription = ["""

pid_t pid;
    const char* args[] = {"killall", "backboardd", NULL};
    posix_spawn(&pid, "/usr/bin/killall", NULL, NULL, (char* const*)args, NULL);
""",
                               """
[[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"#"] options:@{} completionHandler:nil];
""",
                               
                               
                               """
   <dict>
   <key>action</key>
   <string>respring</string>
   <key>cell</key>
   <string>PSButtonCell</string>
   <key>icon</key>
   <string>icon.png</string>
   <key>label</key>
   <string>Button</string>
   </dict>
""",
                               
                               """
       <dict>
       <key>cell</key>
       <string>PSSwitchCell</string>
       <key>default</key>
       <false/>
       <key>defaults</key>
       <string>com.apple.YourTweak</string>
       <key>icon</key>
       <string>picsart.png</string>
       <key>key</key>
       <string>photo</string>
       <key>label</key>
       <string>Enabled</string>
       </dict>
""",
                               
                               """
          <dict>
          <key>cell</key>
          <string>PSGroupCell</string>
          <key>footerText</key>
          <string></string>
          <key>label</key>
          <string></string>
          </dict>
""",
                               
                               """

UIAlertController alertController = [UIAlertController alertControllerWithTitle:@"Hey This is a Test Alert!" message:@"Testing... Testing... 123 Is this thing on?" preferredStyle:UIAlertControllerStyleAlert];
                          UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil];
                          [alertController addAction:alertAction];
                          [self presentViewController:alertController animated:YES completion:nil];
""",
                               """
<dict>
   <key>cell</key>
   <string>PSGroupCell</string>
   <key>footerAlignment</key>
   <string>1</string>
   <key>footerText</key>
   <string> All rights reserved to developer Ahmed Salah ©</string>
  </dict>
""",
                               """
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <UIKit/UIControl.h>
#import <Cephei/HBPreferences.h>
#import <spawn.h>
""",
                               """
TweakName_EXTRA_FRAMEWORKS += Cephei
TweakName_FRAMEWORKS = UIKit
""",
                               """
#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <CepheiPrefs/HBRootListController.h>
#import <CepheiPrefs/HBAppearanceSettings.h>
#import <Cephei/HBPreferences.h>
#import <spawn.h>
#import <Social/SLComposeViewController.h>
#import <Social/SLServiceTypes.h>
#import <Twitter/Twitter.h>
#import <Preferences/PSSpecifier.h>
#import <objc/runtime.h>
#import <Preferences/PSTableCell.h>
#import <Social/SLComposeViewController.h>
#import <Social/SLServiceTypes.h>
#import <Twitter/Twitter.h>
""",
                               
                               "NameTweak_EXTRA_FRAMEWORKS = Cephei CepheiPrefs",
                               
                               """
%config(generator=internal)
%group AnyName



#source code your tweak


%end
%ctor
{
  HBPreferences *Key = [[HBPreferences alloc] initWithIdentifier:@"Bundle your tweak."];
 bool Enable = [([Key objectForKey:@"name in plist"] ?: @(NO)) boolValue];

if (Enable) {
 %init(AnyName);

}
}
"""]
    
    
    
   

    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 12
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
       
        cell.locationName.text = locationNames[indexPath.row]
        cell.locationDescription.text = locationDescription[indexPath.row]
        
        //This creates the shadows and modifies the cards a little bit
        cell.contentView.layer.cornerRadius = 4.0
        cell.contentView.layer.borderWidth = 50
        cell.contentView.layer.borderColor = UIColor.clear.cgColor
        cell.contentView.layer.masksToBounds = false
        cell.layer.shadowColor = UIColor.gray.cgColor
        cell.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        cell.layer.shadowRadius = 1.0
        cell.layer.shadowOpacity = 1.0
        cell.layer.masksToBounds = false
        cell.layer.shadowPath = UIBezierPath(roundedRect: cell.bounds, cornerRadius: cell.contentView.layer.cornerRadius).cgPath
        
        
        return cell
    }

}

