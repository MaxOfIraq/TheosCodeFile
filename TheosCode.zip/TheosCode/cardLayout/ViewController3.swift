//
//  ViewController3.swift
//  TheosCode
//
//  Created by Hussein Salah on 3/3/20.
//  Copyright © 2020 Riley Norris. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {

    @IBOutlet weak var UDID: UILabel!
    @IBOutlet weak var iDeV: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(UIDevice.current.model)
        print(UIDevice.current.identifierForVendor!)
        let dd = UIDevice.current.model as String
        iDeV.text! = dd
        
        ///////////////
        
        let deviceUUID: String = UIDevice.current.identifierForVendor!.uuidString
        UDID.text! = deviceUUID
    }
    

    @IBAction func CopyText(_ sender: Any)
    {
        UIPasteboard.general.string = UDID.text 
    }
    
    
    @IBAction func PayPal(_ sender: Any)
    {
        UIApplication.shared.open(URL(string: "https://www.paypal.me/AhmedSalahStore")! as URL, options : [:],completionHandler: nil)
    }
    
    
    @IBAction func gitHub(_ sender: Any)
    {
        UIApplication.shared.open(URL(string: "https://www.paypal.me/AhmedSalahStore")! as URL, options : [:],completionHandler: nil)
    }
    
    
    
    
    
}
