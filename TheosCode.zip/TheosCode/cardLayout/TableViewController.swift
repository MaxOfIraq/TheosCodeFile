//
//  TableViewController.swift
//  TheosCode
//
//  Created by Hussein Salah on 3/2/20.
//  Copyright © 2020 Riley Norris. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
//    var name =  ["Lesson1: Install Theos", "Lesson2: Create the first Tweak in Cydia", "Lesson3: Create a tweak for the system", "Lesson4: Creating Tool Settings", "Lesson5: Creating Tool Settings 2", "Lesson6: Detailed Explanation of .h and .m", "Lesson7: How to write codes" ]
    
    
    
    var name = ["الدرس الاول : تثبيت الذيوس","الدرس الثاني : انشاء اول اداة في السيديا","الدرس الثالث : انشاء اداة للنضام","الدرس الرابع : انشاء اعدادات للاداة","الدرس الخامس : تكمله اعدادات الاداة","الدرس السادس : شرح مفصل عن الهيدور والمثود","الدرس السابع : طريقة كتابه الاكواد" ]
    
    
    var links = ["https://www.youtube.com/watch?v=YNC8Mtnq5eM","https://www.youtube.com/watch?v=in5qtffHSik&t=14s","https://www.youtube.com/watch?v=_rQ5gerWJWc","https://www.youtube.com/watch?v=d9J4OmPlOTc&t=9s","https://www.youtube.com/watch?v=Fc5dKmL_8aY&t=14s","https://www.youtube.com/watch?v=2loLF45t6AY&t=13s","https://www.youtube.com/watch?v=Dy7_UskHt4o&t=5s"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return name.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = name[indexPath.row]
        
        cell.textLabel?.textColor = UIColor.black
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showLinks" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let destination = segue.destination as? ViewControllerX
                destination?.links = links[indexPath.row]
            }
        }
    }
    
}
