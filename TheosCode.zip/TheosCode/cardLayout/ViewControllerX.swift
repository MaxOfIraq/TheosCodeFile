//
//  ViewControllerX.swift
//  TheosCode
//
//  Created by Hussein Salah on 3/2/20.
//  Copyright © 2020 Riley Norris. All rights reserved.
//

import UIKit
import WebKit

class ViewControllerX: UIViewController, UIWebViewDelegate {
    
    var links: String = ""
    
    @IBOutlet weak var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL (string: links)
        let request = URLRequest(url: url!)
        webView.load(request)
    }
    
    
    
    @IBOutlet weak var Act: UIActivityIndicatorView!
    
    func webViewDidStartLoad(_ webView: UIWebView)
    {
        Act.startAnimating()
    }
    
    
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        Act.stopAnimating()
    }
    
    
    
    
    
}
