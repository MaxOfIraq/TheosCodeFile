//
//  Button.swift
//  TheosCode
//
//  Created by Hussein Salah on 2/27/20.
//  Copyright © 2020 Pooya. All rights reserved.
//

import AVKit
class Button : UIButton{
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.cornerRadius = 10
        self.layer.shadowRadius = 10
        //        self.layer.shadowColor = UIColor.white.cgColor
        self.layer.shadowOpacity = 1
        self.layer.shadowOffset = CGSize(width: 3, height: 3)}}
