//
//  CollectionViewCell.swift
//  cardLayout
//
//  Created by Ahmed Salah on 11/2/19.
//  Copyright © 2019 Ahmed Salah. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var locationName: UILabel!
    @IBOutlet weak var locationDescription: UITextView!
    
}
